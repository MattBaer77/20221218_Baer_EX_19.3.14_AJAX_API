======================
APIs TV Maze: Solution
======================

`Download our solution <../../solution.zip>`_

.. literalinclude:: tvmaze.js
  :language: js
  :caption:
