// simple node class
class Node {
  constructor(val) {
    this.val = val;
    this.next = undefined;
  }
}

// simple list class
class LinkedList {
  constructor() {
    this.head = undefined;
    this.tail = undefined;
    this.length = 0;
  }

  static sumLists(listOne, listTwo) {}
}

module.exports = LinkedList;
