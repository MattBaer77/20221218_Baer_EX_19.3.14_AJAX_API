function objectCompare() {}

module.exports = objectCompare;
