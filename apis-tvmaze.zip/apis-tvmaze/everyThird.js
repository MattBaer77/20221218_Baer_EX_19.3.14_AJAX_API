function everyThird() {}


module.exports = everyThird;

